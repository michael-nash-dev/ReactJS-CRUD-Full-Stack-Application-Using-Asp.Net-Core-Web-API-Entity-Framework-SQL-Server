import React, {useState, useEffect} from "react";
import { Row, Col, Button } from "react-bootstrap";
import { Link, useParams } from "react-router-dom";


const ActorDetail = (props) =>{

    const[actor, setActor] = useState(null);
    const{actorid} = useParams();

    useEffect(() => {
        if (actorid) {
            fetch(`${process.env.REACT_APP_API_URL}/person/${actorid}`)
                .then(res => res.json())
                .then(res => {
                    if (res.status === true) {
                        setActor(res.data);
                       
                    }
                })
                .catch(err => alert("Error in getting data"));
        }

    },[actorid]);



    return (
        <Row>
            {actor &&
            <>
               

                <Col item xs={12} md={12}>
                    <h3>{actor.name}</h3>
                    <div><b>Date of birth:</b></div>
                    <div>{actor.dateofBirth && actor.dateofBirth.split('T')[0]}</div>
                    <div><b>Movies:</b></div>
                    <ul>{actor.movies.map((x) => <li key={x}>{x}</li>)}</ul>
                </Col>

                <Col>
                    <Link to ="/actors">Go to actors page</Link>
                </Col>
            </>
            }
        </Row>
    )
}

export default ActorDetail;
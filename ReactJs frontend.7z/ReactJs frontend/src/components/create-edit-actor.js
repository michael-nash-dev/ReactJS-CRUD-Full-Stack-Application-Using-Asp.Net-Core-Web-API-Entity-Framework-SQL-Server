import React from "react";

const CreateEditActor = () =>{

    return (
        <>
             
        </>
    )
}

export default CreateEditActor;